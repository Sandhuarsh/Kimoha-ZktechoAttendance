app_name = "zkteco_checkins_sync"
app_title = "ZKTeco Checkin Sync"
app_publisher = "osama.ahmed@deliverydevs.com"
app_description = "This app pulls transactions from device and creates Employee Checkin records."
app_email = "osama.ahmed@deliverydevs.com"
app_license = "mit"

# Apps
# ------------------

# required_apps = []

# Each item in the list will be shown as an app in the apps page
# add_to_apps_screen = [
# 	{
# 		"name": "zkteco_checkins_sync",
# 		"logo": "/assets/zkteco_checkins_sync/logo.png",
# 		"title": "ZKTeco Checkin Sync",
# 		"route": "/zkteco_checkins_sync",
# 		"has_permission": "zkteco_checkins_sync.api.permission.has_app_permission"
# 	}
# ]

# Includes in <head>
# ------------------

# include js, css files in header of desk.html
# app_include_css = "/assets/zkteco_checkins_sync/css/zkteco_checkins_sync.css"
# app_include_js = "/assets/zkteco_checkins_sync/js/zkteco_checkins_sync.js"

# include js, css files in header of web template
# web_include_css = "/assets/zkteco_checkins_sync/css/zkteco_checkins_sync.css"
# web_include_js = "/assets/zkteco_checkins_sync/js/zkteco_checkins_sync.js"

# include custom scss in every website theme (without file extension ".scss")
# website_theme_scss = "zkteco_checkins_sync/public/scss/website"

# include js, css files in header of web form
# webform_include_js = {"doctype": "public/js/doctype.js"}
# webform_include_css = {"doctype": "public/css/doctype.css"}

# include js in page
# page_js = {"page" : "public/js/file.js"}

# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

# Svg Icons
# ------------------
# include app icons in desk
# app_include_icons = "zkteco_checkins_sync/public/icons.svg"

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
# 	"Role": "home_page"
# }

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# Jinja
# ----------

# add methods and filters to jinja environment
# jinja = {
# 	"methods": "zkteco_checkins_sync.utils.jinja_methods",
# 	"filters": "zkteco_checkins_sync.utils.jinja_filters"
# }

# Installation
# ------------

# before_install = "zkteco_checkins_sync.install.before_install"
# after_install = "zkteco_checkins_sync.install.after_install"

# Uninstallation
# ------------

# before_uninstall = "zkteco_checkins_sync.uninstall.before_uninstall"
# after_uninstall = "zkteco_checkins_sync.uninstall.after_uninstall"

# Integration Setup
# ------------------
# To set up dependencies/integrations with other apps
# Name of the app being installed is passed as an argument

# before_app_install = "zkteco_checkins_sync.utils.before_app_install"
# after_app_install = "zkteco_checkins_sync.utils.after_app_install"

# Integration Cleanup
# -------------------
# To clean up dependencies/integrations with other apps
# Name of the app being uninstalled is passed as an argument

# before_app_uninstall = "zkteco_checkins_sync.utils.before_app_uninstall"
# after_app_uninstall = "zkteco_checkins_sync.utils.after_app_uninstall"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "zkteco_checkins_sync.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways

# permission_query_conditions = {
# 	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
# 	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# DocType Class
# ---------------
# Override standard doctype classes

# override_doctype_class = {
# 	"ToDo": "custom_app.overrides.CustomToDo"
# }

# Document Events
# ---------------
# Hook on document methods and events

# doc_events = {
# 	"*": {
# 		"on_update": "method",
# 		"on_cancel": "method",
# 		"on_trash": "method"
# 	}
# }

# Scheduled Tasks
# ---------------
# IMPORTANT: scheduler_events must be a STATIC dict. Never query the DB here —
# hooks.py is imported on every request/migrate/build, often with no DB context,
# which previously caused errors and blanked the desk. The frequency logic now
# lives inside scheduled_sync() (it reads each config's `seconds` field there).

scheduler_events = {
    "cron": {
        # Runs every minute; scheduled_sync() decides per-device whether enough
        # time has passed (based on each ZKTeco Config's Sync Frequency).
        "* * * * *": [
            "zkteco_checkins_sync.zkteco_checkin_sync.doctype.zkteco_config.zkteco_config.scheduled_sync"
        ]
    }
}

# Testing
# -------

# before_tests = "zkteco_checkins_sync.install.before_tests"

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
# 	"frappe.desk.doctype.event.event.get_events": "zkteco_checkins_sync.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
# 	"Task": "zkteco_checkins_sync.task.get_dashboard_data"
# }

# exempt linked doctypes from being automatically cancelled
#
# auto_cancel_exempted_doctypes = ["Auto Repeat"]

# Ignore links to specified DocTypes when deleting documents
# -----------------------------------------------------------

# ignore_links_on_delete = ["Communication", "ToDo"]

# Request Events
# ----------------
# before_request = ["zkteco_checkins_sync.utils.before_request"]
# after_request = ["zkteco_checkins_sync.utils.after_request"]

# Job Events
# ----------
# before_job = ["zkteco_checkins_sync.utils.before_job"]
# after_job = ["zkteco_checkins_sync.utils.after_job"]

# User Data Protection
# --------------------

# user_data_fields = [
# 	{
# 		"doctype": "{doctype_1}",
# 		"filter_by": "{filter_by}",
# 		"redact_fields": ["{field_1}", "{field_2}"],
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_2}",
# 		"filter_by": "{filter_by}",
# 		"partial": 1,
# 	},
# 	{
# 		"doctype": "{doctype_3}",
# 		"strict": False,
# 	},
# 	{
# 		"doctype": "{doctype_4}"
# 	}
# ]

# Authentication and authorization
# --------------------------------

# auth_hooks = [
# 	"zkteco_checkins_sync.auth.validate"
# ]

# Automatically update python controller files with type annotations for this app.
# export_python_type_annotations = True

# default_log_clearing_doctypes = {
# 	"Logging DocType Name": 30  # days to retain logs
# }